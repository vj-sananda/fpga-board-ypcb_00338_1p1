# Usage with Vitis IDE:
# In Vitis IDE create a Single Application Debug launch configuration,
# change the debug type to 'Attach to running target' and provide this 
# tcl script in 'Execute Script' option.
# Path of this script: /home/tiferking/WorkPlace/Vitis/YPCB_00338_1P1_App_system/_ide/scripts/debugger_ypcb_00338_1p1_app-default.tcl
# 
# 
# Usage with xsct:
# In an external shell use the below command and launch symbol server.
# symbol_server -S -s tcp::1534
# To debug using xsct, launch xsct and run below command
# source /home/tiferking/WorkPlace/Vitis/YPCB_00338_1P1_App_system/_ide/scripts/debugger_ypcb_00338_1p1_app-default.tcl
# 
connect -path [list tcp::1534 tcp:192.168.100.97:3121]
targets -set -filter {jtag_cable_name =~ "Digilent JTAG-HS1 210512180081" && level==0 && jtag_device_ctx=="jsn-JTAG-HS1-210512180081-23751093-0"}
fpga -file /home/tiferking/WorkPlace/Vitis/YPCB_00338_1P1_App/_ide/bitstream/top_wrapper.bit
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
loadhw -hw /home/tiferking/WorkPlace/Vitis/YPCB_00338_1P1_plat/export/YPCB_00338_1P1_plat/hw/top_wrapper.xsa -regs
configparams mdm-detect-bscan-mask 2
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
rst -system
after 3000
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
dow /home/tiferking/WorkPlace/Vitis/YPCB_00338_1P1_App/Debug/YPCB_00338_1P1_App.elf
targets -set -nocase -filter {name =~ "*microblaze*#0" && bscan=="USER2" }
con
