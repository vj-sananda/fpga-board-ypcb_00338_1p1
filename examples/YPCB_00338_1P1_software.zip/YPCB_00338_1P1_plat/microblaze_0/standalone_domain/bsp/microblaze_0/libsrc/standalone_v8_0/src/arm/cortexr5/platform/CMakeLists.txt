add_subdirectory(${MACHINE})
